"""
DSC 20 Winter 2024 Homework 04
Name: TODO
PID: TODO
Source: TODO
"""

# Question 1
def know_plant(path):
    """
    ##############################################################
    # TODO: Replace this block of comments with your own         #
    # method description and add at least 3 more doctests below. #
    ##############################################################

    >>> know_plant('files/diary01.txt')
    {'Harrada': ['Paralyze', 'Silence']}
    >>> know_plant('files/diary02.txt')
    {'Harrada': ['Paralyze'], 'Flame Stalk': ['Invisibility']}

    # Add at least 3 doctests below here #
    """
    # YOUR CODE GOES HERE #
    return


# Question 2
def create_potion(plants, path):
    """
    ##############################################################
    # TODO: Replace this block of comments with your own         #
    # method description and add at least 3 more doctests below. #
    ##############################################################

    >>> dict1 = {'Harrada': ['Paralyze', 'Silence']}
    >>> create_potion(dict1, "files/potion1.txt")
    >>> with open("files/potion1.txt", 'r') as f:
    ...     for l in f:
    ...         print(l.strip())
    Harrada
    Potion
    Paralyze,Silence
    >>> dict2 = {'Harrada': ['Paralyze'], 'Flame Stalk': ['Paralyze'],\
'Stone Flower': ['Paralyze']}
    >>> create_potion(dict2, "files/potion2.txt")
    >>> with open("files/potion2.txt", 'r') as f:
    ...     for l in f:
    ...         print(l.strip())
    Harrada
    Flame Stalk
    Stone Flower
    Poison
    Paralyze

    # Add at least 3 doctests below here #
    """
    # YOUR CODE GOES HERE #
    return



# Question 3
def potion_name(plants):
    """
    ##############################################################
    # TODO: Replace this block of comments with your own         #
    # method description and add at least 3 more doctests below. #
    ##############################################################

    >>> input_1 = [('Harrada', 'yellow', 19), ('Flame Stalk', 'red', 13), \
('Stone Flower', 'gray', 32), ('Crystal Snowflake', 'blue', 48), \
('Foxglove', 'pink', 20), ('Dangerous Nightshade', 'purple', 18)]
    >>> potion_name(input_1)
    'Adaalkade'

    >>> input_2 = [('White Snakeroot', 'white', 19), \
('Bitter Hogweed', 'black', 13)]
    >>> potion_name(input_2)
    'Whibit'

    >>> input_3 = []
    >>> potion_name(input_3)
    ''

    # Add at least 3 doctests below here #
    """
    # YOUR CODE GOES HERE #
    return



# Question 4
def trade(potions, prices, consumer_list):
    """
    ##############################################################
    # TODO: Replace this block of comments with your own         #
    # method description and add at least 3 more doctests below. #
    ##############################################################

    >>> trade(['health', 'magic'], [10, 10], ['health', 'magic'])
    20
    >>> trade(['health', 'magic', 'large_health'], [10, 20, 30], \
    ['health', 'large_health', 'magic'])
    50
    >>> trade(['health', 'magic', 'large_health', 'large_magic'],\
    [5, 10, 15, 20], ['magic', 'health', 'large_health'])
    25

    # Add at least 3 doctests below here #
    """
    # YOUR CODE GOES HERE #
    return


# Question 5
def potion_magic(potions, operations):
    """
    ##############################################################
    # TODO: Replace this block of comments with your own         #
    # method description and add at least 3 more doctests below. #
    ##############################################################

    >>> potion_magic("incorrect input", ['mix'])
    Traceback (most recent call last):
    ...
    AssertionError

    >>> potion_magic(['health', 'magic'], ['eliminate', 'reduce'])
    ['hea', 'mag']
    >>> potion_magic(['health_large_potion', 'health'], ['eliminate', 'mix'])
    'htlaeh'

    # Add at least 3 doctests below here #
    """

    # TODO: Fill out the lambda functions as dictionary values
    # Break lines if go past 79 characters
    op_dict = {
        'mix': lambda lst: ...,
        'reduce': lambda lst: ...,
        'eliminate': lambda lst: ...
    }

    # YOUR CODE GOES HERE #
    return
