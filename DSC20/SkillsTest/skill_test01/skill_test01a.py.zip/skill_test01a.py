def add_numbers(a,b):
    """
    Function to add 2 numbers together.

    args:
        a (int): number to be added
        b (int): number to be added
    returns:
        the sum of a,b

    >>> add_numbers(1,1)
    2
    """
    return 'a' + b