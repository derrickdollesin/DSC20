"""
DSC 20 Winter 2024 Homework 01
Name: TODO
PID: TODO
Source: TODO
"""

# Question 1.1

def helper_distance(coord1, coord2):
    """
    ##############################################################
    # TODO: Replace this block of comments with your own         #
    # method description and add at least 3 more doctests below. #
    ##############################################################

    >>> helper_distance(['1', '2'], ['4', '6'])
    5.0
    >>> round(helper_distance(['3', '2'], ['40', '6']), 3)
    37.216

    # Add your own doctests below
    """
    # YOUR CODE GOES HERE #
    return

# Question 1.2
def safe_location(your_loc, safe_loc, jump_length):
    """
    ##############################################################
    # TODO: Replace this block of comments with your own         #
    # method description and add at least 3 more doctests below. #
    ##############################################################

    >>> your_loc = "1, 2"
    >>> safe_loc = "4, 6"
    >>> ans = safe_location(your_loc, safe_loc, 10)
    >>> print(ans)
    Nice jump!
    You are safe to continue.


    >>> your_loc = "3, 2"
    >>> safe_loc = "40, 6"
    >>> safe_location(your_loc, safe_loc, 15)
    'You are sent back home.'
    
    # Add your own doctests below
    """
    # YOUR CODE GOES HERE #
    return


# Question 2.1
def first_pattern(repeat, symbol):
    """
    ##############################################################
    # TODO: Replace this block of comments with your own         #
    # method description and add at least 3 more doctests below. #
    ##############################################################

    >>> first_pattern(3, '*')
    '***'
    >>> first_pattern(6, '$')
    '$$$$$$'

    # Add your own doctests below
    """
    # YOUR CODE GOES HERE #
    return 

# Question 2.2
def second_pattern(repeat, symbol, word, repeat_again):
    """
    ##############################################################
    # TODO: Replace this block of comments with your own         #
    # method description and add at least 3 more doctests below. #
    ##############################################################

    >>> second_pattern(3, '*', 'pattern', 2)
    '**nrettap***'
    >>> second_pattern(6, '$', 'journey', 3)
    '$$$yenruoj$$$$$$'
    >>> second_pattern(3, '', '', 2)
    ''

    # Add your own doctests below
    """
    # YOUR CODE GOES HERE #
    return 

# Question 2.3
def third_pattern(word, switch):
    """
    ##############################################################
    # TODO: Replace this block of comments with your own         #
    # method description and add at least 3 more doctests below. #
    ##############################################################

    >>> third_pattern("trip", True)
    'TRIPtripTRIP'
    >>> third_pattern("dangerous", False)
    'dangerousDANGEROUSdangerous'

    # Add your own doctests below
    """
    # YOUR CODE GOES HERE #
    return
    
# Question 2.4
def fourth_pattern(symbols, repeats, switch):
    """
    ##############################################################
    # TODO: Replace this block of comments with your own         #
    # method description and add at least 3 more doctests below. #
    ##############################################################

    >>> fourth_pattern(['-', '+'], [4, 5], True)
    '----+++++'
    >>> fourth_pattern(['-', '+'], [4, 5],  False)
    '+++++----'

    >>> fourth_pattern([], [],  False)
    ''

    # Add your own doctests below
    """
    # YOUR CODE GOES HERE #
    return


# Question 3
def shortest_bridge(bridge1, bridge2, bridge3):
    """
    ##############################################################
    # TODO: Replace this block of comments with your own         #
    # method description and add at least 3 more doctests below. #
    ##############################################################

    >>> shortest_bridge("flame","deep river", "flower")
    'bridge1'
    >>> shortest_bridge("hot flames","river", "flower")
    'bridge2'
    >>> shortest_bridge("flame","river", "calm and green")
    'bridge1'
    >>> shortest_bridge("very dangerous","deep river", "red flower")
    'bridge2'

    # Add your own doctests below
    """
    # YOUR CODE GOES HERE #
    return

# Question 4.1
def average_without_min_max(people):
    """
    ##############################################################
    # TODO: Replace this block of comments with your own         #
    # method description and add at least 3 more doctests below. #
    ##############################################################
    >>> average_without_min_max([10, 10, 1, 16])
    10.0
    >>> average_without_min_max([2, 4, 10, 7, 9])
    6.67
    >>> average_without_min_max([2, 0, 10, 5])
    3.5

    # Add your own doctests below
    """
    # YOUR CODE GOES HERE #
    return


# Question 4.2
def best_average_bridge(people, bridges):
    """
    ##############################################################
    # TODO: Replace this block of comments with your own         #
    # method description and add at least 3 more doctests below. #
    ##############################################################

    >>> ratings = [[1, 10, 5], [4, 6, 9]]
    >>> names = ["flames", "river"]
    >>> best_average_bridge(ratings, names)
    'river'

    >>> ratings = [[6, 10, 5, 3, 8], [10, 10, 9], [6, 6, 90]]
    >>> names = ["flames", "flower", "river"]
    >>> best_average_bridge(ratings, names)
    'flower'

    >>> ratings = [[], [], []]
    >>> names = ["flames", "flower", "river"]
    >>> best_average_bridge(ratings, names)
    'flames'

    >>> best_average_bridge([], [])
    'No bridges to choose from'

    # Add your own doctests below
    """
    # YOUR CODE GOES HERE #
    return


# Question 5
def sleepy_vs_awake(flowers):
    """
    ##############################################################
    # TODO: Replace this block of comments with your own         #
    # method description and add at least 3 more doctests below. #
    ##############################################################

    >>> sleepy_vs_awake(["Sleeperose", "Rose", "Sleeperose"])
    'Sleeperose'
    >>> sleepy_vs_awake(["Sleeperose", "Awakentia", "rose"])
    True
    >>> sleepy_vs_awake(["rose", "sleeperose", "awakentia", "daisy"])
    False
    >>> sleepy_vs_awake(["rose", "sleeperose", "Awakentia", "daisy"])
    'Awakentia'

    # Add your own doctests below
    """
    # YOUR CODE GOES HERE #
    return


# Question 6
def sign(bridge_type, hint, your_name):
    """
    ##############################################################
    # TODO: Replace this block of comments with your own         #
    # method description and add at least 3 more doctests below. #
    ##############################################################

    >>> print(sign("Flower bridge", "Do the opposite.", "Dr. Who"))
    Dear traveler,
    Please be careful with the Flower bridge. My advice is: Do the opposite.
    <BLANKLINE>
    See you in Pythonia: Dr. Who
    >>> print(sign("Flame Bridge", "Do not be afraid of it.", ""))
    Dear traveler,
    Please be careful with the Flame Bridge. My advice is: Do not be \
afraid of it.
    <BLANKLINE>
    See you in Pythonia: 

    # Add your own doctests below
    """
    # YOUR CODE GOES HERE #
    return


# Question 7
def my_nickname(first, last, age):
    """
    ##############################################################
    # TODO: Replace this block of comments with your own         #
    # method description and add at least 3 more doctests below. #
    ##############################################################

    >>> my_nickname("Marina", "Langlois", 25)
    '2aiaLANGLOIS5'
    >>> my_nickname("Marina", "Langlois", 2.5)
    'Error'
    >>> my_nickname("", "Langlois", 25)
    '2LANGLOIS5'
    >>> my_nickname("", "Langlois", 5)
    '0LANGLOIS5'

    # Add your own doctests below
    """
    # YOUR CODE GOES HERE #
    return

